package top.lrshuai.googlecheck.common;

public enum CacheEnum {
    LOGIN,GOOGLE
}
