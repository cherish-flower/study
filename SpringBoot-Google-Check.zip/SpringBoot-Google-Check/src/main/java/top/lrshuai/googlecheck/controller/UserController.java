package top.lrshuai.googlecheck.controller;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import top.lrshuai.googlecheck.annotation.NeedLogin;
import top.lrshuai.googlecheck.base.BaseController;
import top.lrshuai.googlecheck.common.Result;
import top.lrshuai.googlecheck.dto.GoogleDTO;
import top.lrshuai.googlecheck.dto.LoginDTO;
import top.lrshuai.googlecheck.service.UserService;
import top.lrshuai.googlecheck.utils.QRCodeUtil;
import java.io.OutputStream;

@Controller
@RequestMapping("/user")

public class UserController extends BaseController {

    @Autowired
    private UserService userService;

    @GetMapping("/register")
    @ResponseBody
    public Result register(LoginDTO dto) throws Exception {
        return userService.register(dto);
    }


    @GetMapping("/login")
    @ResponseBody
    public Result login(LoginDTO dto)throws Exception{
        return userService.login(dto);
    }


    @GetMapping("/generateGoogleSecret")
    @ResponseBody
    @NeedLogin
    public Result generateGoogleSecret()throws Exception{
        return userService.generateGoogleSecret(this.getUser());
    }

    /**
     * 注意：这个需要地址栏请求,因为返回的是一个流
     * 注意：这个需要地址栏请求,因为返回的是一个流
     * 注意：这个需要地址栏请求,因为返回的是一个流
     * 显示一个二维码图片
     * @param secretQrCode   generateGoogleSecret接口返回的：secretQrCode
     * @param response
     * @throws Exception
     */
    @GetMapping("/genQrCode")
     public void genQrCode(String secretQrCode, HttpServletResponse response) throws Exception{
        response.setContentType("image/png");
        OutputStream stream = response.getOutputStream();
        QRCodeUtil.encode(secretQrCode,stream);
    }


    @GetMapping("/bindGoogle")
    @ResponseBody
    @NeedLogin
    public Result bindGoogle(GoogleDTO dto)throws Exception{
        return userService.bindGoogle(dto,this.getUser(),this.getRequest());
    }

    @GetMapping("/googleLogin")
    @ResponseBody
    @NeedLogin
    public Result googleLogin(Long code) throws Exception{
        return userService.googleLogin(code,this.getUser(),this.getRequest());
    }


    @GetMapping("/getData")
    @NeedLogin(google = true)
    @ResponseBody
    public Result getData()throws Exception{
        return userService.getData();
    }

}
