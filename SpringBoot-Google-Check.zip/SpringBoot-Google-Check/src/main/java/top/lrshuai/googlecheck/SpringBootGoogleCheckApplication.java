package top.lrshuai.googlecheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGoogleCheckApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootGoogleCheckApplication.class, args);
    }

}
