package top.lrshuai.googlecheck.common;

public class Consts {
    /**
     * 前端传上来的 token 参数
     */
    public static final String TOKEN = "token";

    public static final String SUCCESS = "SUCCESS";

}
